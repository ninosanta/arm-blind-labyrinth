#ifndef		GAME_H
#define		GAME_H

void gameOpening(void);
void gameInit(void);
void gameClear(void);
void gameRestart(void);

#endif	// GAME_H
