char checkVal(char a, char b);
void robot_init(void);
void robot_set_coord(char a, char b);
void robot_set_dir(char dir);
void proximity(void);
void rotate(void);
void step(void);
void newTimerVal(char timerN, unsigned int timerV);
unsigned int robotGetLED(void);
